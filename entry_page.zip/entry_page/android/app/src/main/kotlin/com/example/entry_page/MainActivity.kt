package com.example.entry_page

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
